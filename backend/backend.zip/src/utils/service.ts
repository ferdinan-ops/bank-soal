export const userSelect = {
  select: {
    id: true,
    fullname: true,
    email: true,
    photo: true,
    provider: true,
    role: true
  }
}
