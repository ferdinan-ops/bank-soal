export interface IGetParams {
  page: number
  limit: number
  search: string
}
