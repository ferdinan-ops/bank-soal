import Logo from './icons/logo.svg'

export { Logo }
