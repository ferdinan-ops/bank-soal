export enum UserRole {
  ADMIN = 'ADMIN',
  SISWA = 'SISWA',
  GURU = 'GURU'
}
