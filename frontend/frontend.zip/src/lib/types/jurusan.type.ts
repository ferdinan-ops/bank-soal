export type JurusanBodyType = {
  nama: string
}

export type JurusanType = {
  id: string
} & JurusanBodyType
