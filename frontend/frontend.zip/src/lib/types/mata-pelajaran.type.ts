export type MataPelajaranBodyType = {
  nama: string
}

export type MataPelajaranType = {
  id: string
} & MataPelajaranBodyType
