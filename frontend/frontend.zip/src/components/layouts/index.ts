import MainLayout from './MainLayout'

export { MainLayout }
