import useTitle from './useTitle'
import useOutsideClick from './useOutsideClick'
import useDisableBodyScroll from './useDisableBodyScroll'
import useGetDevices from './useGetDevices'
import useDebounce from './useDebounce'
import useQueryParams from './useQueryParams'
import { usePagination } from './usePagination'
import useRemovePointerEvent from './useRemovePointerEvent'
import useTimer from './useTimer'

export {
  useTitle,
  useOutsideClick,
  useDisableBodyScroll,
  useGetDevices,
  useDebounce,
  useQueryParams,
  usePagination,
  useRemovePointerEvent,
  useTimer
}
