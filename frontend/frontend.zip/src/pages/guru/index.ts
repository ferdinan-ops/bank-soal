import GuruSoal from './GuruSoal'
import GuruSoalCreate from './GuruSoalCreate'
import GuruSoalDetail from './GuruSoalDetail'
import GuruSoalDetailCreate from './GuruSoalDetailCreate'
import GuruScore from './GuruScore'

export { GuruSoal, GuruSoalCreate, GuruSoalDetail, GuruSoalDetailCreate, GuruScore }
