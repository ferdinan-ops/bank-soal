import GuruSoal from './GuruSoal'
import GuruScore from './GuruScore'
import GuruSoalDetail from './GuruSoalDetail'
import GuruSoalCreate from './GuruSoalCreate'
import GuruSoalDetailCreate from './GuruSoalDetailCreate'

export { GuruSoal, GuruSoalCreate, GuruSoalDetail, GuruSoalDetailCreate, GuruScore }
