import Guru from './Guru'
import Kelas from './Kelas'
import Jurusan from './Jurusan'
import Mengajar from './Mengajar'
import MataPelajaran from './MataPelajaran'

export { Jurusan, Kelas, Guru, MataPelajaran, Mengajar }
