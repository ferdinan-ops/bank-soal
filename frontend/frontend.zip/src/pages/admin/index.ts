import Jurusan from './Jurusan'
import Kelas from './Kelas'
import Guru from './Guru'
import MataPelajaran from './MataPelajaran'
import Mengajar from './Mengajar'

export { Jurusan, Kelas, Guru, MataPelajaran, Mengajar }
