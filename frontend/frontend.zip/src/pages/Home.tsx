import { Loading, Pagination, Search } from '@/components/atoms'
import { Info } from '@/components/organisms'
import { Button } from '@/components/ui/button'
import { Form, FormField, FormItem } from '@/components/ui/form'
import { useDisableBodyScroll, useQueryParams, useTitle } from '@/hooks'
import { UserRole } from '@/lib/constant'
import { useUserInfo } from '@/store/client'
import { useGetSoal } from '@/store/server/useSoal'
import { useForm } from 'react-hook-form'
import { useNavigate } from 'react-router-dom'

interface FormFields {
  search: string
}

export default function Home() {
  useTitle('Beranda')

  const navigate = useNavigate()
  const forms = useForm<FormFields>()

  const user = useUserInfo((state) => state.user)
  const { params, createParam, deleteParam } = useQueryParams(['page', 'search'])

  const {
    data: soal,
    isLoading,
    isFetching,
    refetch
  } = useGetSoal({
    page: Number(params.page) || 1,
    q: params.search || ''
  })

  useDisableBodyScroll(isLoading)

  const onSubmit = (data: FormFields) => {
    if (data.search === '' || data.search === undefined) {
      deleteParam('search')
    } else {
      createParam({ key: 'search', value: data.search })
    }

    refetch()
  }

  console.log(soal)

  return (
    <section className="flex flex-col gap-6">
      {(isLoading || isFetching) && <Loading />}

      <div className="flex items-center justify-between">
        <div className="flex flex-col">
          <h2 className="mb-2 text-2xl font-bold text-primary dark:text-white md:text-[32px]">Daftar Soal</h2>
          <p className="text-[13px] font-medium text-zinc-500 md:text-sm">
            Berikut adalah seluruh daftar soal yang telah didaftarkan pada sistem.
          </p>
        </div>
        <Form {...forms}>
          <form onSubmit={forms.handleSubmit(onSubmit)} className="ml-auto flex w-4/12 items-center">
            <FormField
              name="search"
              control={forms.control}
              render={({ field }) => (
                <FormItem className="w-full">
                  <Search {...field} value={field.value ?? ''} placeholder="Cari soal" containerClassName="w-full" />
                </FormItem>
              )}
            />
          </form>
        </Form>
      </div>

      <div className="grid grid-cols-3 gap-8">
        {soal?.data.length && soal.data.length > 0 ? (
          soal?.data.map((item) => (
            <article className="rounded-lg bg-[#F7F9FB] p-6" key={item.id}>
              <h1 className="text-xl font-bold">{item.mengajar.mata_pelajaran.nama}</h1>
              <table className="mt-5 w-fit text-sm">
                <tbody>
                  <Info title="Jurusan" content={item.mengajar.kelas.jurusan.nama} />
                  <Info title="Kelas" content={item.mengajar.kelas.nama} />
                  <Info title="Tahun Ajaran" content={item.mengajar.tahun_ajaran} />
                  <Info title="Semester" content={item.semester} />
                  <Info title="Pengajar" content={item.mengajar.guru.user.fullname} />
                </tbody>
              </table>
              <div className="mt-8 flex w-full items-center justify-between">
                <div className="flex flex-col">
                  <p className="text-xs font-semibold text-primary/60">Lama pengerjaan:</p>
                  <p className="text-sm font-semibold">{item.lama_pengerjaan} menit</p>
                </div>
                <Button
                  className="ml-auto px-4 xl:text-xs"
                  onClick={() => navigate(`/answer/${item.id}/time/${item.lama_pengerjaan}`)}
                >
                  {user.role === UserRole.SISWA ? 'Jawab' : 'Lihat'} Soal
                </Button>
              </div>
            </article>
          ))
        ) : params?.search ? (
          <p className="font-semibold italic text-primary/80">Tidak ada soal dengan data: {params?.search}</p>
        ) : (
          <p className="font-semibold italic text-primary/80">Belum ada soal</p>
        )}
      </div>
      {soal?.meta && soal?.meta?.total > 9 ? (
        <Pagination
          pageSize={soal?.meta.limit as number}
          totalCount={soal?.meta.total as number}
          currentPage={params.page !== '' ? parseInt(params.page) : 1}
          onPageChange={(page) => createParam({ key: 'page', value: page.toString() })}
        />
      ) : null}
    </section>
  )
}
